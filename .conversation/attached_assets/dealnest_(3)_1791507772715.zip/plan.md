
## Experience upgrade: branded motion and grounded discovery

- **Design movement:** Neon editorial commerce cockpit with a playful 3D mascot moment at entry, then restrained motion in the product UI.
- **Core principles:** Make freshness visible, separate live quotes from directory coverage, explain the next action, and keep every animation interruptible.
- **Color philosophy:** Preserve DealNest's lime/prism-purple signature; lime signals verified action and purple signals the discovery engine, while muted ink keeps dense comparisons readable.
- **Layout paradigm:** Use a layered command surface—live status rail, comparison cards, and guided action steps—rather than adding decorative motion to every card.
- **Signature elements:** A blinking-eyed DN cube/mascot, orbiting price rings, and source/eligibility chips for grounded results.
- **Interaction/animation:** Show the branded intro for a bounded 3.2 seconds on each fresh tab, respect reduced-motion preferences, and never block a returning user indefinitely. Keep data refresh and AI status explicit.
- **Typography/voice:** Retain the existing display/system pairing; use concise labels such as “Google-grounded search” and “Checkout confirmation required.”
- **Brand essence:** DealNest is a transparent India-first comparison cockpit for shoppers who want the lowest landed cost, not a promise of universal web coverage. Personality: sharp, candid, helpful.
- **Data boundary:** The AI may use the configured Google Search grounding tool when available and must cite returned sources. The app will not claim to crawl the entire Google index, invent 10,000 coupons, or present directory-only partner coverage as live pricing. It will label live catalog data, grounded web evidence, and checkout-only coverage separately.
- **Project structure:** `ThreeDLoader` and `index.css` own the entry animation; `AiAssistant` owns grounded status/source rendering and step-by-step guidance; `data.ts`/coupon types own eligibility-rich verified seed data; `server.ts` owns AI grounding instructions and response metadata.

## Permanent hosting implementation

- **Serving model:** Keep the existing React/Vite frontend and Express API together in one Node container. Vite builds `dist/`; Express serves it in production and continues to own `/api/*` routes.
- **Deployment contract:** Use the committed `Dockerfile`, `npm ci`, `npm run build`, `npm start`, port `3000`, and unauthenticated `/_app/health` readiness endpoint.
- **Data and credentials:** Preserve the current file-backed auth/config behavior for this deployment and keep `GEMINI_API_KEY` runtime-only when configured. No credentials are committed to the browser bundle.
- **Preview/publication:** Keep `/manus-routes.json` as the page manifest, validate the managed Preview after startup, save a checkpoint to the canonical Manus repository, then publish the checkpoint as the permanent server-backed website.

### Project structure

- `src/` — React application, components, catalog data, utilities, and styles.
- `server.ts` — Express API, authentication/admin routes, AI assistant, health endpoint, and production static serving.
- `server/authService.ts` and `data/auth_db.json` — existing application authentication/config store.
- `public/` — static route manifest and public assets.
- `api/` — existing API helper source retained with the application.
- `Dockerfile` and `package*.json` — reproducible production image build and runtime.
