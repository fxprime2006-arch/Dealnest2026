# DealNest platform and offer research

Research basis: public official pages plus source discovery/cross-check pages. GrabOn was used internally for discovery only and is not shown or promoted in the product. Any offer without a published expiry or offer-specific official terms is labeled in the UI as **verify at checkout**.

## Platform records

- **Amazon India** — Official Electronics & accessories sale listing showed product-level sale prices and a Samsung Galaxy Tab S12 Ultra listing with a ₹15,000 coupon shown. No universal code or expiry was published. Sources: https://www.amazon.in/b?ie=UTF8&node=83208890031 and https://www.amazon.in/gp/help/customer/display.html?nodeId=GPW59RAF7826AEFD
- **Flipkart** — Official Big Billion Days page showed up to 10% Axis/ICICI card discount, 10% first Supermoney transaction, EMI offers, Pay Later offer and 5% UPI gift-card discount. Codes and end date were not published. Source: https://www.flipkart.com/big-billion-days-store
- **Myntra** — Visible offer records included MYNTRA300 (new-user/app offer), STACKUP (₹400 above ₹2,499 or ₹800 above ₹5,000), NOREASON10 and an official first-order ₹400 claim. Official checkout confirmation is required. Sources: https://www.myntra.com/myntra-coupon-offer and https://www.myntra.com/myntra-coupons
- **AJIO** — Official offers and policy pages visibly list FIRSTBUY, FIRSTAPP, FREE149, FLASH/SNAP and FORHER. AJIO’s policy says first purchase offers are selected-product, one-use promotions that may be modified or withdrawn. Sources: https://www.ajio.com/offers, https://www.ajio.com/ajio-sale-policy and https://www.ajio.com/coupon-faq
- **Nykaa** — Official Coupons & Offers page visibly listed NEW10, EXTRA400I (orders above ₹1,500), EXTRA10% and EXTRA20%. Expiry and complete terms were not visible. Source: https://www.nykaa.com/coupons-offers
- **Swiggy** — Visible source records included up to 50% off above ₹159 capped at ₹100, ₹200 off above ₹499, up to 30% off above ₹179 capped at ₹75, and Instamart free-shipping/₹75 offers. Offer-specific official validity was not exposed. Sources: https://www.swiggy.com/offer-terms and https://www.swiggy.com/instamart
- **Zomato** — Official homepage visibly listed Gold free delivery within 7 km. Other public offer URLs checked were expired/no longer valid and were excluded. Source: https://www.zomato.com/
- **Blinkit** — Visible records included Paytm cashback up to ₹100 above ₹750, HDFC PayZapp cashback above ₹500, Axis Bank card discount, BHIM RuPay offer above ₹599 and free delivery above ₹199. Official terms say promotions may be changed or discontinued. Source: https://blinkit.com/terms
- **Zepto** — Official pages and visible listings included the Supersaver milestone reward, QUICKSAVE200 (source-visible, checkout verification), MobiKwik/Amazon Pay payment offers, and a product-level rice deal. Zepto terms state promotional vouchers can lapse, expire or be revoked. Sources: https://www.zepto.com/s/terms-of-service and https://www.zepto.com/s/zepto-supersaver-monthly-milestones
- **MakeMyTrip** — Official homepage and flight offer pages visibly showed first-booking, hotel, international-flight and domestic-flight savings. Codes, expiry and complete terms were not published in the extracted page. Sources: https://www.makemytrip.com/ and https://www.makemytrip.com/flights/domestic-flight-offer.html
- **BookMyShow** — Official offers listing showed YES Bank MARQUEE BOGO through 31 Dec 2026, IDFC FIRST Private Card up to ₹750 twice monthly through 31 Mar 2027, RBL offers through 31 Jul 2027 and DBS Spark BOGO up to ₹200 through 31 Jul 2027. Source: https://in.bookmyshow.com/offers
- **JioMart** — Visible records included ₹25 off fruits & vegetables above ₹149, ₹30 off above ₹199, grocery deals, AU Bank 10% up to ₹300 above ₹2,000 and Bank of Baroda 10% up to ₹500 above ₹1,000. Current official expiry/terms were not accessible. Source: https://www.jiomart.com/offers

## Implementation rule

Never render a source-discovery listing as a guaranteed active coupon. Codes are copied only when a visible source published them; otherwise `code` stays null. Expiry is `Not published` when no source date exists. The checkout confirmation notice remains visible on every offer card.
