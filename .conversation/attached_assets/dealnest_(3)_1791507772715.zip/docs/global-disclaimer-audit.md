# Global Disclaimer + Admin Live IP Audit

## Architecture

1. **Versioned global setting**: one current disclaimer text and monotonically increasing version. Updating the text increments the version.
2. **Session acceptance**: every authenticated session stores the exact accepted version. A session is blocked whenever its accepted version is lower than the current version.
3. **Server enforcement**: the UI modal is only the user experience. Protected resource endpoints must also reject requests until the server verifies the session's accepted version.
4. **Audit trail**: every security-relevant event is written server-side with a stable user ID, proxy-resolved IP, action, description, and millisecond timestamp. The browser cannot choose or override the IP.
5. **Realtime propagation**: an SSE stream broadcasts `disclaimer.updated` to open screens. SSE is suitable for one instance; use Redis Pub/Sub or a managed broker when multiple instances are deployed.
6. **Privacy**: IP addresses are sensitive personal data. Restrict audit routes to administrators, encrypt the database at rest, define a retention period, and publish an appropriate privacy notice.

> No application can guarantee a “real” public IP when a user is behind a VPN, carrier NAT, privacy relay, or an untrusted proxy. The server records the client IP asserted by the configured trusted edge. Never accept an IP supplied in a JSON body.

## PostgreSQL schema

```sql
create table if not exists global_settings (
  id smallint primary key default 1 check (id = 1),
  disclaimer_version bigint not null default 1,
  disclaimer_text text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null default 'system'
);

create table if not exists user_sessions (
  session_id uuid primary key,
  user_id text not null,
  accepted_disclaimer_version bigint not null default 0,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);

create table if not exists activity_logs (
  id bigserial primary key,
  user_id text not null,
  ip_address inet not null,
  action text not null check (char_length(action) between 1 and 80),
  description text not null check (char_length(description) <= 500),
  occurred_at timestamptz not null default clock_timestamp(),
  metadata jsonb not null default '{}'::jsonb
);

create index if not exists activity_logs_user_time_idx on activity_logs (user_id, occurred_at desc);
create index if not exists activity_logs_ip_time_idx on activity_logs (ip_address, occurred_at desc);
create index if not exists activity_logs_time_idx on activity_logs (occurred_at desc);

insert into global_settings (disclaimer_text)
values ('This platform is free to use. Information is provided for general resource and comparison purposes, may change without notice, and should be independently verified before you act. No content on this platform is a guarantee, endorsement, or substitute for your own judgment.')
on conflict (id) do nothing;
```

### Atomic disclaimer update

```sql
update global_settings
set disclaimer_text = $1,
    disclaimer_version = disclaimer_version + 1,
    updated_at = clock_timestamp(),
    updated_by = $2
where id = 1
returning disclaimer_version, disclaimer_text, updated_at;
```

## Express implementation rules

The live implementation in `server.ts` and `server/authService.ts` uses the same contract with the repository's existing store. The production migration target is the PostgreSQL schema above.

### Trusted proxy IP resolution

```ts
function getClientIp(req: Request): string {
  // Only use these headers when the deployment edge is trusted and configured.
  const cf = req.headers['cf-connecting-ip'];
  if (typeof cf === 'string' && cf.trim()) return cf.trim();
  const real = req.headers['x-real-ip'];
  if (typeof real === 'string' && real.trim()) return real.trim();
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string' && forwarded.split(',')[0]?.trim()) {
    return forwarded.split(',')[0].trim();
  }
  return req.socket.remoteAddress || '0.0.0.0';
}

app.set('trust proxy', 1); // Match the actual number of trusted reverse proxies.
```

Do not use `req.body.ip`, a client-side JavaScript IP lookup, or an arbitrary forwarded header when the server is directly internet-facing. Configure the edge so direct clients cannot spoof these headers.

### Audit writer and acceptance guard

```ts
async function audit(req: Request, userId: string, action: string, description: string, metadata = {}) {
  await db.query(
    `insert into activity_logs (user_id, ip_address, action, description, metadata)
     values ($1, $2::inet, $3, $4, $5::jsonb)`,
    [userId, getClientIp(req), action, description, JSON.stringify(metadata)]
  );
}

async function requireCurrentDisclaimer(req: Request, res: Response, next: NextFunction) {
  const session = await getSessionFromBearerToken(req);
  if (!session) return res.status(401).json({ error: 'Authentication required.' });
  const { rows } = await db.query('select disclaimer_version, disclaimer_text, updated_at from global_settings where id = 1');
  const setting = rows[0];
  if (session.accepted_disclaimer_version !== setting.disclaimer_version) {
    return res.status(428).json({
      error: 'Current disclaimer acceptance required.',
      disclaimer: { required: true, version: setting.disclaimer_version, text: setting.disclaimer_text, updatedAt: setting.updated_at },
    });
  }
  res.locals.session = session;
  next();
}
```

Apply `requireCurrentDisclaimer` to every endpoint that exposes a protected free resource. The modal is not a security boundary by itself.

### SSE update channel

```ts
const clients = new Set<Response>();
app.get('/api/disclaimer/stream', (req, res) => {
  res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive' });
  res.flushHeaders();
  clients.add(res);
  res.write(`event: ready\\ndata: ${JSON.stringify(currentSetting)}\\n\\n`);
  const heartbeat = setInterval(() => res.write(': heartbeat\\n\\n'), 25000);
  req.on('close', () => { clearInterval(heartbeat); clients.delete(res); });
});

function broadcast(setting: object) {
  const message = `event: disclaimer.updated\\ndata: ${JSON.stringify(setting)}\\n\\n`;
  for (const client of clients) client.write(message);
}
```

After the admin `UPDATE`, broadcast the returned version/text. In a horizontally scaled deployment, publish the event to Redis and have each instance broadcast it to its own connected clients.

## React blocking flow

```tsx
const [disclaimer, setDisclaimer] = useState<Disclaimer | null>(null);

useEffect(() => {
  if (!userToken) return;
  fetch('/api/disclaimer/current', { headers: { Authorization: `Bearer ${userToken}` } })
    .then(r => r.json())
    .then(data => setDisclaimer(data.disclaimer));

  const stream = new EventSource('/api/disclaimer/stream');
  stream.addEventListener('disclaimer.updated', event => {
    const update = JSON.parse((event as MessageEvent).data);
    setDisclaimer({ ...update, required: true });
  });
  return () => stream.close();
}, [userToken]);

async function accept(version: number) {
  const response = await fetch('/api/disclaimer/accept', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${userToken}` },
    body: JSON.stringify({ version }),
  });
  if (!response.ok) throw new Error('The disclaimer changed; reload it.');
  setDisclaimer(current => current && { ...current, required: false });
}

return disclaimer?.required ? <BlockingDisclaimerModal disclaimer={disclaimer} onAccept={accept} /> : <App />;
```

The shipped `GlobalDisclaimerModal.tsx` uses a controlled checkbox, disables the accept button until checked, displays the exact server text, handles version conflicts, and remains blocking if the network request fails. CSS/DOM changes cannot unlock protected API endpoints because the server checks the accepted version on every protected request.

## Required operational controls

- Use HTTPS everywhere.
- Keep bearer tokens out of URLs and logs.
- Redact IPs and user IDs from ordinary application logs.
- Restrict `/api/admin/audit-logs` and disclaimer management to admin sessions.
- Add retention/deletion policy for IP logs (for example, 30–90 days where legally appropriate).
- Validate and length-limit admin disclaimer input; render it as text, not HTML, to prevent XSS.
- Use PostgreSQL transactions for “update setting + audit + outbox event” in production.
- Add rate limiting to authentication and audit endpoints.
