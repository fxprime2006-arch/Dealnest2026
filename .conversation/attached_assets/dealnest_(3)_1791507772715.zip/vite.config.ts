import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname || '.', '.'),
      },
    },
    server: {
      // Managed Preview proxies HTTP but not Vite's separate HMR socket.
      // Keep HMR disabled so the browser never attempts a broken WebSocket connection.
      hmr: false,
      // Allow the sandbox's public proxy hostname during development.
      allowedHosts: ['.manus.computer'],
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
